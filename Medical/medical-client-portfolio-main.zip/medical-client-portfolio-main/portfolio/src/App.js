import Routes from "./Router";
import "./static/stylesheets/styles.css";

function App() {
  return <Routes />;
}

export default App;
