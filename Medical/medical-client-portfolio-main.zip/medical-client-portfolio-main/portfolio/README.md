# Client Portfolio

## Reference Links

### [Kanban board](https://github.com/akshat-rawat/medical-client-portfolio/projects/3)

### Templates
[https://www.herbeshwari.com/](https://www.herbeshwari.com/)\
[https://vivekanandahealth.com/](https://vivekanandahealth.com/)\
[http://drrukshinmaster.com/](http://drrukshinmaster.com/)


## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.
