
const Blogs = () => {
    return <>
      Blogs
    </>;
  }
  
  export default Blogs;