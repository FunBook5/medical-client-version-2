
const Testimonials = () => {
  return <>
    Testimonials
  </>;
}

export default Testimonials;